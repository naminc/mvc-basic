<?php
date_default_timezone_set('Asia/Ho_Chi_Minh');
define("LOCALHOST", "localhost");
define("USERNAME", "root");
define("PASSWORD", "");
define("DB_NAME", "basic_sql");

?>